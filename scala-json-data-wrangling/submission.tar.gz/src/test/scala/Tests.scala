import Wrangling._

// You will need to write more tests.
class TestSuite extends org.scalatest.FunSuite {

  test("Empty test works") {
    assert(true)
  }

}

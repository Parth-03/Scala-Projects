class Tests extends org.scalatest.FunSuite {

  import PathImplicits._
  import TimeImplicits._

}
